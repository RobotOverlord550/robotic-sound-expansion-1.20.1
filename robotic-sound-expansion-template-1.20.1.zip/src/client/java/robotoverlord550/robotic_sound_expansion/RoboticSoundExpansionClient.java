package robotoverlord550.robotic_sound_expansion;

import net.fabricmc.api.ClientModInitializer;

public class RoboticSoundExpansionClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}